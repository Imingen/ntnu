Each task is completed in seperate .py files.

The assignment said to add visualisations for all the maps 
in task 1 and 2 and additonal visualisations for tasks 3, 
these visualisations are .png images of the boards.
Each image is a picture of two boards, one before start 
and one at the end. This is just for a better overview on my part. 
The images are pretty self explanatory but anways:
Paths are yellow on the map with 'dot like' symbol
Start and Goal state doest change color for better visualisation
Nodes in the closed set are marked with the letter 'C' and are black
Nodes in the open set are marked with the letter 'O' and are pinkish

a_star.py is the first file i completed and after that I copied the code
to a_star_2 and a_star_3 to add the additional details. Since I commented
after I was done with all the tasks I only commented the first file the heaviest
since it is the same code in all the files. Any additional changes in the other
files have been commented. 

